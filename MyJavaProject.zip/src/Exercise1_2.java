public class Exercise1_2 {
    public static void main(String[] args) {
        System.out.println("I love Java");
        System.out.println("I love Java");
        System.out.println("I love Java");
        System.out.println("I love Java");
        System.out.println("I love Java");
    }
}
