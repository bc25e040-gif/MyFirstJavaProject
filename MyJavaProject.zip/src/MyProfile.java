public class MyProfile {
    public static void main(String[] args) {
        System.out.println("*******************************");
        System.out.println("*         My Profile          *");
        System.out.println("*******************************");
        System.out.println("Name: Zeng Jingwen");          // 
        System.out.println("Matric: BC25E040");           // 
        System.out.println("State/Province: Guangdong");  // 
        System.out.println("Is this program your first choice?: Yes"); // 
        System.out.println("Expectations from this course: Learn programming basics."); // 
    }
}
