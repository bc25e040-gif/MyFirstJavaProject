public class Exercise1_5 {
    public static void main(String[] args) {
        double result = (7.5 * 6.5 - 4.5 * 3) / (47.5 - 5.5);
        System.out.println("The result of the expression is: " + 0.8392857142857143);
    }
}